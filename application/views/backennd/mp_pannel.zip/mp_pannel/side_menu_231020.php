
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->            <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a href="<?php echo base_url(); ?>MP_Panel/">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
           
            <li class="sub-menu">
      <!--          <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>Reports</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo base_url(); ?>MP_Panel/bank_reports">Generate Report</a></li>
                    <li><a href="<?php echo base_url(); ?>MP_Panel/bank_reports">Report Check List</a></li>
                </ul>
            </li>
-->
      <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>Missionary Management</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo base_url(); ?>MP_Panel/add_missionary/first">New Missionary</a></li>
                    <li><a href="<?php echo base_url(); ?>MP_Panel/missionaries">Missionary List</a></li>
                <!--         <li><a href="<?php echo base_url(); ?>MP_Panel/missionary_retirement">Missionary Retirement</a></li>-->
                 
                </ul>
            </li>
         
           
            
        </ul></div>        
<!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->