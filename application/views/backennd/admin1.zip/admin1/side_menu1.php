
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->            <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a href="<?php echo base_url(); ?>Admin/">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>Finance Core</span>
                </a>
                <ul class="sub">
                    <li><a href="#">Bank Export</a></li>
                 
                </ul>
            </li>
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>Budget Request</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo base_url(); ?>Admin2/generate_otherregular">Other Regular</a></li>
                    <li><a href="<?php echo base_url(); ?>Admin2/generate_irregular">Irregular</a></li>
                    <li><a href="<?php echo base_url(); ?>Admin2/generate_mbudget">Monthly Budget</a></li>
                 
                </ul>
            </li>
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>Missionary Report</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo base_url(); ?>Admin2/new_reports">New Reports</a></li>
                    <li><a href="#">Download</a></li>
                    <li><a href="#">Missing Report</a></li>
                    <li><a href="#">Report Analysis</a></li>
                 
                </ul>
            </li>

        
           
            
        </ul></div>        
<!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->