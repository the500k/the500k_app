
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->            <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a href="#">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>Donar's Panel</span>
                </a>
                <ul class="sub">
                    <li><a href="<?php echo base_url(); ?>Admin3/donar_analysis">Donar Analysis</a></li>
                    <li><a href="<?php echo base_url(); ?>Admin3/donar_report">Donar Report</a></li>
                 
                </ul>
            </li>
        <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-laptop"></i>
                    <span>Donar Management</span>
                </a>
                <ul class="sub">
                    <li><a href="#">Donars List</a></li>
                    <li><a href="#">Send Email</a></li>
                 
                </ul>
            </li>
         
        </ul></div>        
<!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->